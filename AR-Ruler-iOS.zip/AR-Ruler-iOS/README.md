# AR-Ruler-iOS Application
Virtual Ruler for measuring distance between two points
Created AR project which can measure the distance between two points given on a horizontal plane
Explored basic AR concepts such as ARSession, ARWorldTrackingConfiguration, ARHitTestResult ,plane detection, Scene/node generation, node positioning 

